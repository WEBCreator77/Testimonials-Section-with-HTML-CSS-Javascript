const slider = document.querySelector(".slider").children;
const indicatorImage = document.querySelector(".slider-indicator").children;

for (let i = 0; i < indicatorImage.length; i++) {
       indicatorImage[i].addEventListener("click", function () {
              for (let j = 0; j < indicatorImage.length; j++) {
                     indicatorImage[j].classList.remove("active");
              }
              this.classList.add("active");

              const id = this.getAttribute("data-id");
              for (let j = 0; j < slider.length; j++) {
                     slider[j].classList.remove("active");
              }
              slider[id].classList.add("active");
       })
}






















